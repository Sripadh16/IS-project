import unittest
from cache_model import MultiCoreCacheSystem,EvictionHiddenBuffer,AdaptiveEvictionHiddenBuffer
from attacks import force_llc_eviction

class CacheTests(unittest.TestCase):
    def test_no_cross_domain_eviction(self):
        for cls in (EvictionHiddenBuffer,AdaptiveEvictionHiddenBuffer):
            b=cls(4)
            self.assertTrue(b.insert(1,{0},True,1))
            for j in range(2,20):b.insert(j,{1},False,j)
            self.assertTrue(b.contains(1))
    def test_private_sharer_eviction(self):
        c=MultiCoreCacheSystem('treasure_cache',8,llc_sets=32,llc_ways=4)
        a=0x100000
        c.read_address(0,a,0,True)
        self.assertTrue(force_llc_eviction(c,a,count=6))
        self.assertTrue(c.ehb.contains(a//64))
        self.assertEqual(c.read_address(0,a,0,True)[1],'EHB_HIT')
        self.assertFalse(c.ehb.contains(a//64))
        self.assertIn(a//64,c.llc[c._set(a//64)])
    def test_no_sharers_no_buffer(self):
        c=MultiCoreCacheSystem('treasure_cache',8,llc_sets=32,llc_ways=4)
        a=0x100000
        c.read_address(0,a,0)
        c._invalidate_private(a//64)
        force_llc_eviction(c,a,count=6)
        self.assertFalse(c.ehb.contains(a//64))
    def test_ct_flush(self):
        for mode in ('treasure_cache','ada_ehb'):
            c=MultiCoreCacheSystem(mode)
            self.assertEqual(c.clflush(0,0x100000),70)
            c.read_address(0,0x100000,0)
            self.assertEqual(c.clflush(0,0x100000),70)
    def test_adaptive_bypass_protects_other_domain(self):
        b=AdaptiveEvictionHiddenBuffer(2)
        b.insert(1,{0},True,1)
        for i in range(2,15):b.insert(i,{1},False,i)
        self.assertIn(1,b.entries)

if __name__=='__main__':unittest.main()
