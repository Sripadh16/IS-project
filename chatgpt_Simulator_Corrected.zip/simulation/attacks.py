"""Reproducible cache eviction tests; synthetic timing oracle, not AES key recovery."""
import random
from cache_model import MultiCoreCacheSystem

class AESVictimWorkload:
    def __init__(self, base_addr=0x100000):
        self.base_addr=base_addr
        self.secret_key=0xA7
    def get_line_for_byte(self,val):
        return (val>>4)&15
    def get_address_for_line(self,line):
        return self.base_addr+line*64
    def execute_encryption_round(self,sys,plaintext_byte):
        return sys.read_address(0,self.get_address_for_line(self.get_line_for_byte(plaintext_byte^self.secret_key)),0,True)

def force_llc_eviction(sys, address, domain=1, count=None):
    """Evict address's LLC set with conflicting lines on attacker core.
    Return the actual target eviction state, rather than presuming eviction.
    """
    idx=(address//64)%sys.llc_sets
    for j in range(count or sys.llc_ways+2):
        block=(100000+j)*sys.llc_sets+idx
        sys.read_address(1,block*64,domain)
    return (address//64) not in sys.llc[idx]

def run_residency_trial(mode, capacity, churn, seed, working_set=8):
    """Compare buffer residency after identical domain-1 contention.
    Churn is *not* asserted to bypass the original ownership defense.
    """
    sys=MultiCoreCacheSystem(mode,capacity,seed,llc_sets=32,llc_ways=4)
    rng=random.Random(seed)
    victim=[(0x100000//64+i)*64 for i in range(working_set)]
    # Touch victim and force each victim line out of LLC using conflict addresses.
    for a in victim:
        sys.read_address(0,a,0,True)
    for a in victim:
        force_llc_eviction(sys,a,count=6)
    before=sum(sys.ehb.contains(a//64) for a in victim) if sys.ehb else 0
    # Adversary owns distinct lines; the ownership rule should prevent cross-domain displacement.
    for j in range(churn):
        addr=((200000+j)*sys.llc_sets+(j%sys.llc_sets))*64
        sys.read_address(1,addr,1)
    retained=sum(sys.ehb.contains(a//64) for a in victim) if sys.ehb else 0
    # Probe only previously buffered victim lines to avoid inflating the denominator.
    results=[]
    for a in victim:
        lat,level=sys.read_address(0,a,0,True)
        results.append({'latency':lat,'level':level})
    return {'initial_buffered':before,'retained':retained,'working_set':working_set,
            'ehb_hits':sum(r['level']=='EHB_HIT' for r in results),
            'dram_misses':sum(r['level']=='DRAM_MISS' for r in results),
            'mean_latency':sum(r['latency'] for r in results)/len(results),
            'stats':sys.stats,'bypasses':sys.ehb.bypasses if sys.ehb else 0}

def run_evict_and_time_simulation(mode='none',rounds=50,seed=42,thrash_intensity=0):
    """Matched control vs evicted single-line victim access; no fabricated gap."""
    rng=random.Random(seed)
    evicted=[]; control=[]; levels=[]
    for i in range(rounds):
        a=0x100000
        baseline=MultiCoreCacheSystem(mode,64,seed+i,llc_sets=32,llc_ways=4)
        baseline.read_address(0,a,0,True)
        # Remove private copy but leave LLC resident for an LLC-hit control.
        baseline._invalidate_private(a//64)
        c,_=baseline.read_address(0,a,0,True)
        control.append(c)
        target=MultiCoreCacheSystem(mode,64,seed+i,llc_sets=32,llc_ways=4)
        target.read_address(0,a,0,True)
        force_llc_eviction(target,a,count=6)
        for j in range(thrash_intensity):
            target.read_address(1,((300000+j)*32+j%32)*64,1)
        v,level=target.read_address(0,a,0,True)
        evicted.append(v);levels.append(level)
    return {'timing_gap':sum(evicted)/rounds-sum(control)/rounds,
            'mean_evicted':sum(evicted)/rounds,'mean_cached':sum(control)/rounds,
            'evicted_samples':evicted,'cached_samples':control,
            'ehb_hit_fraction':levels.count('EHB_HIT')/rounds,
            'levels':{k:levels.count(k) for k in set(levels)}}
