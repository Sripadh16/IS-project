"""Educational, sequential cache-event simulator; NOT cycle-accurate gem5.
64-byte lines, inclusive private L1/L2 and shared LLC; shared physical blocks
have independent per-domain owners and per-core sharer tracking.
"""
import math
import random
from dataclasses import dataclass, field

LINE_SIZE = 64

@dataclass
class BufferEntry:
    address: int
    owners: set
    sensitive: bool
    time: int
    last_access: int
    frequency: int = 1

class EvictionHiddenBuffer:
    def __init__(self, capacity_lines=64, hit_latency=40, num_domains=2):
        self.capacity = capacity_lines
        self.hit_latency = hit_latency
        self.quota = max(1, capacity_lines // num_domains)
        self.entries = {}
        self.hits = self.misses = self.evictions = self.bypasses = 0

    def contains(self, addr):
        return addr in self.entries

    def take(self, addr, time):
        entry = self.entries.pop(addr, None)
        if entry is None:
            self.misses += 1
        else:
            self.hits += 1
        return entry

    def _eligible(self, owners):
        # An insertion may replace only an entry whose owners are a subset of
        # the incoming block's owners. This conservative rule prevents one
        # domain from evicting a block owned by a different domain.
        return [(a,e) for a,e in self.entries.items() if e.owners.issubset(owners)]

    def insert(self, addr, owners, sensitive, time):
        owners = set(owners)
        if not owners or self.capacity == 0:
            self.bypasses += 1
            return False
        if addr in self.entries:
            e = self.entries[addr]
            e.owners |= owners
            e.sensitive |= sensitive
            return True
        # The quota is a conservative admission cap on *solely-owned* entries.
        # Shared entries count against all their owners via the eligibility rule.
        for d in owners:
            if sum(d in e.owners for e in self.entries.values()) >= self.quota:
                eligible = [(a,e) for a,e in self._eligible(owners) if d in e.owners]
                if not eligible:
                    self.bypasses += 1
                    return False
                break
        else:
            eligible = self._eligible(owners) if len(self.entries) >= self.capacity else []
        if eligible:
            key = min(eligible, key=lambda item: item[1].last_access)[0]
            del self.entries[key]
            self.evictions += 1
        elif len(self.entries) >= self.capacity:
            self.bypasses += 1
            return False
        self.entries[addr] = BufferEntry(addr, owners, sensitive, time, time)
        return True

class AdaptiveEvictionHiddenBuffer(EvictionHiddenBuffer):
    def __init__(self, capacity_lines=64, hit_latency=40, num_domains=2):
        super().__init__(capacity_lines, hit_latency, num_domains)
        self.alpha = .2
        self.tokens = {d: 8.0 for d in range(num_domains)}
        self.updated = {d: 0 for d in range(num_domains)}

    def score(self, entry, time):
        age = max(1, time - entry.last_access)
        return (3.0 if entry.sensitive else 1.0) * (1+self.alpha*entry.frequency) / math.log(1+age+1e-5)

    def insert(self, addr, owners, sensitive, time):
        owners = set(owners)
        if addr in self.entries:
            e = self.entries[addr]
            e.owners |= owners
            e.sensitive |= sensitive
            return True
        if not sensitive:
            for d in owners:
                elapsed = max(0, time-self.updated[d])
                self.tokens[d] = min(8.0, self.tokens[d] + elapsed/125.0)
                self.updated[d] = time
                if self.tokens[d] < 1:
                    self.bypasses += 1
                    return False
        if not owners or not self.capacity:
            self.bypasses += 1
            return False
        must_replace = len(self.entries) >= self.capacity or any(
            sum(d in e.owners for e in self.entries.values()) >= self.quota for d in owners
        )
        if must_replace:
            eligible = self._eligible(owners)
            # Prefer nonsensitive entries, but never violate domain ownership.
            nonsensitive = [(a,e) for a,e in eligible if not e.sensitive]
            if nonsensitive:
                eligible = nonsensitive
            if not eligible:
                self.bypasses += 1
                return False
            key, old = min(eligible, key=lambda x: (self.score(x[1],time),x[1].last_access))
            incoming = BufferEntry(addr,owners,sensitive,time,time)
            if not sensitive and self.score(incoming,time) <= self.score(old,time):
                self.bypasses += 1
                return False
            # No irrevocable protection is claimed when all eligible entries are sensitive.
            del self.entries[key]
            self.evictions += 1
        self.entries[addr] = BufferEntry(addr,owners,sensitive,time,time)
        if not sensitive:
            for d in owners:
                self.tokens[d] -= 1
        return True

class MultiCoreCacheSystem:
    def __init__(self, mode='none', ehb_capacity=64, seed=42, llc_sets=2048, llc_ways=16):
        self.mode = mode
        self.time = 0
        self.rng = random.Random(seed)
        self.l1 = [dict(),dict()]
        self.l2 = [dict(),dict()]
        self.llc = [dict() for _ in range(llc_sets)]
        self.llc_sets = llc_sets
        self.llc_ways = llc_ways
        self.sharers = {}  # block -> set(core IDs)
        self.owners = {}   # block -> set(domain IDs), physical-page ownership approximation
        self.sensitive = set()
        self.ehb = (EvictionHiddenBuffer(ehb_capacity) if mode=='treasure_cache' else
                    AdaptiveEvictionHiddenBuffer(ehb_capacity) if mode=='ada_ehb' else None)
        self.stats = {'llc_evictions':0,'back_invalidations':0,'ehb_eligible':0,'ehb_inserted':0}

    def _set(self, block):
        return block % self.llc_sets

    def _private_add(self, core, block):
        # bounded private caches with LRU (L1 512 lines, L2 4096 lines)
        for cache,limit in ((self.l1[core],512),(self.l2[core],4096)):
            cache.pop(block,None)
            cache[block] = self.time
            if len(cache)>limit:
                oldest = next(iter(cache))
                del cache[oldest]
                if oldest not in self.l1[core] and oldest not in self.l2[core]:
                    self.sharers.get(oldest,set()).discard(core)
        self.sharers.setdefault(block,set()).add(core)

    def _invalidate_private(self, block):
        had = bool(self.sharers.get(block))
        for c in range(2):
            self.l1[c].pop(block,None)
            self.l2[c].pop(block,None)
        self.sharers.pop(block,None)
        if had:
            self.stats['back_invalidations'] += 1
        return had

    def _install_llc(self, block, domain, from_ehb=False):
        idx = self._set(block)
        group = self.llc[idx]
        group.pop(block,None)
        # Partitioning: eight ways per domain, using disjoint ownership classes.
        if self.mode == 'partitioned':
            owned = [b for b in group if domain in self.owners.get(b,set())]
            if len(owned)>=self.llc_ways//2:
                self._evict_llc(min(owned,key=lambda b:group[b]),idx,from_ehb)
        elif len(group)>=self.llc_ways:
            self._evict_llc(min(group,key=lambda b:group[b]),idx,from_ehb)
        group[block]=self.time

    def _evict_llc(self, victim, idx, from_ehb):
        self.llc[idx].pop(victim,None)
        self.stats['llc_evictions']+=1
        had_sharers = self._invalidate_private(victim)
        # Original dual condition: private sharers OR eviction caused by EHB reload.
        if self.ehb and (had_sharers or from_ehb):
            self.stats['ehb_eligible']+=1
            if self.ehb.insert(victim,self.owners.get(victim,set()),victim in self.sensitive,self.time):
                self.stats['ehb_inserted']+=1

    def read_address(self, core_id, addr, domain_id, is_sensitive=False):
        block = addr//LINE_SIZE
        self.owners.setdefault(block,set()).add(domain_id)
        if is_sensitive:
            self.sensitive.add(block)
        if block in self.l1[core_id]:
            self._private_add(core_id,block)
            self.time+=4
            return 4,'L1_HIT'
        if block in self.l2[core_id]:
            self._private_add(core_id,block)
            self.time+=12
            return 12,'L2_HIT'
        idx=self._set(block)
        if block in self.llc[idx]:
            self.llc[idx][block]=self.time
            self._private_add(core_id,block)
            self.time+=38
            return 38,'LLC_HIT'
        entry = self.ehb.take(block,self.time) if self.ehb else None
        if entry:
            self._install_llc(block,domain_id,from_ehb=True)
            self._private_add(core_id,block)
            self.time+=40
            return 40,'EHB_HIT'
        self._install_llc(block,domain_id)
        self._private_add(core_id,block)
        latency=200+self.rng.randint(-4,8)
        self.time+=latency
        return latency,'DRAM_MISS'

    def clflush(self, core_id, addr):
        block=addr//LINE_SIZE
        cached = self._invalidate_private(block)
        cached = (self.llc[self._set(block)].pop(block,None) is not None) or cached
        if self.ehb:
            cached = (self.ehb.entries.pop(block,None) is not None) or cached
        latency = 70 if self.ehb else (95 if cached else 45)
        self.time+=latency
        return latency
