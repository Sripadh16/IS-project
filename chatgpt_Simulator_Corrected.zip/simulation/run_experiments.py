"""Run honest, reproducible experiments; results are not paper-level validation."""
import json
import os
import statistics
import matplotlib.pyplot as plt
from attacks import run_residency_trial,run_evict_and_time_simulation

SEEDS=[101,202,303,404,505]
MODES=['none','treasure_cache','ada_ehb']

def summary(values):
    return {'mean':round(statistics.mean(values),3),
            'std_across_seeds':round(statistics.stdev(values),3) if len(values)>1 else 0,
            'per_seed':[round(x,3) for x in values]}

def main():
    results={'model':'sequential synthetic cache-event simulator; not cycle-accurate',
             'seeds':SEEDS,'warning':'Results do not establish a TreasureCache vulnerability or AES key recovery.',
             'residency':{},'timing':{}}
    for mode in MODES:
        for cap in (8,16,32,64):
            for churn in (0,32,128):
                samples=[run_residency_trial(mode,cap,churn,s) for s in SEEDS]
                key=f'{mode}_capacity{cap}_churn{churn}'
                results['residency'][key]={
                    'buffered_before_churn':summary([s['initial_buffered'] for s in samples]),
                    'buffered_after_churn':summary([s['retained'] for s in samples]),
                    'ehb_hits':summary([s['ehb_hits'] for s in samples]),
                    'dram_misses':summary([s['dram_misses'] for s in samples]),
                    'mean_victim_latency':summary([s['mean_latency'] for s in samples])}
        for churn in (0,64):
            runs=[run_evict_and_time_simulation(mode,rounds=40,seed=s,thrash_intensity=churn) for s in SEEDS]
            results['timing'][f'{mode}_churn{churn}']={
                'timing_gap':summary([x['timing_gap'] for x in runs]),
                'ehb_hit_fraction':summary([x['ehb_hit_fraction'] for x in runs]),
                'levels_seed_101':runs[0]['levels']}
    directory=os.path.dirname(__file__)
    with open(os.path.join(directory,'simulation_results.json'),'w') as f:
        json.dump(results,f,indent=2)
    for metric,filename,ylabel in [('buffered_after_churn','fig1_residency.png','Buffered victim lines'),
                                   ('mean_victim_latency','fig2_victim_latency.png','Mean victim access latency (cycles)')]:
        fig,ax=plt.subplots(figsize=(8,4.5))
        for mode in MODES[1:]:
            xs=[8,16,32,64]
            ys=[results['residency'][f'{mode}_capacity{c}_churn128'][metric]['mean'] for c in xs]
            ax.plot(xs,ys,marker='o',label=mode)
        ax.set(xlabel='EHB capacity (lines)',ylabel=ylabel,title='Synthetic domain-isolated churn; five seeds')
        ax.legend();fig.tight_layout();fig.savefig(os.path.join(directory,filename),dpi=160);plt.close(fig)
    print('Completed; inspect simulation_results.json. No unsupported attack-accuracy graph produced.')

if __name__=='__main__':
    main()
