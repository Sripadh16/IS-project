# TreasureCache / Ada-EHB — corrected educational simulator

## Scope and limitations

This is a **sequential synthetic cache-event model**, NOT gem5, a hardware implementation, or a cycle-accurate simulation. It does not reproduce the original paper's complete ownership state machine, memory coherence protocol, power/area estimates, or cryptographic key recovery. Domain ownership is represented conservatively as a set of domains associated with a physical line. EHB entries are removed on reload and installed into the LLC. Private-cache residency is modeled with bounded LRU dictionaries, not hardware-accurate set-associative L1/L2 behavior. The `sensitive` flag is externally provided, not discovered by hardware. The rate limiter is a proposed heuristic and is not demonstrated to be secure. There is no legitimate application IPC measurement.

**Important:** The generated figures must NOT be substituted into the existing presentation/report without rewriting the claims and explaining these limitations. Previous Prime+Probe secret-recovery percentages and the earlier Ada-EHB superiority graph are not verified by this package. The corrected experiment does NOT establish an exploitable weakness in the original TreasureCache architecture.

## Files

- `cache_model.py`: inclusive cache-event model, conservative domain-isolated replacement, dual-condition EHB placement, EHB-to-LLC reload, CT-Flush and adaptive replacement.
- `attacks.py`: targeted LLC eviction, controlled residency experiment, matched LLC-hit versus post-eviction timing experiment.
- `run_experiments.py`: repeatable five-seed experiments and new plots.
- `test_simulation.py`: five behavioral regression tests.
- `simulation_results.json`: fresh results from corrected code.
- `fig1_residency.png`, `fig2_victim_latency.png`: generated plots.

## Run

```bash
python -m pip install matplotlib
python -m unittest -v
python run_experiments.py
```

Run these commands from the `simulation` folder. Python 3.10+ recommended. NumPy is not required.

## Interpretation

The test uses an 8-line sensitive victim working set and separate-domain attacker churn. The domain-isolated replacement rule means the attacker does not evict victim-owned buffer entries. For 8-entry EHB, the two-domain quota permits four victim-owned lines, so four accesses go to DRAM. For capacities 16 and above, all eight victim lines remain buffered in this setup. Both implementations produce the same results, which is expected under this conservative threat model.

## Future validation required

1. Precisely model the original paper's security-domain ownership states, thresholds and sharer acquisition.
2. Model shared-memory contention with per-domain sharers and prove the attack can legally displace protected lines under the original policy.
3. Add an independently tested Prime+Probe experiment, with meaningful signal rather than a synthetic timing oracle.
4. Compare identical attack workloads and record actual victim timing, EHB hits, misses, and statistical variation.
5. Run gem5 or comparable detailed simulation before claiming cycle accuracy, security guarantees, IPC improvements or silicon-area overhead.
